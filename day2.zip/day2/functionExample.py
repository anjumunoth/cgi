def myFunc1(p1):
    """Find if p1 is a prime number or not """
    if(p1==2):
        print(f"{p1} is a prime number")

    elif(p1==0)or(p1==1):
        print(f"{p1}is neither prime nor composite")
    elif (p1<0):
        print(f"p1 cannot be negative")
    else:
        for i in range(2,int(p1/2)):
            if(p1 % 2 ==0):
                print(f"{p1}is not a prime number")
                break;
        else:
            print(f"{p1}is a prime number")

#num1=int(input("Enter a number"))
num1=10;
myFunc1(num1)

#by value ; by reference

#pass by value -- int -- primitive data type -- value -- stack
def myFunc2(p1,p2):
    """swap the values"""
    p1=p1+p2;
    p2=p1-p2;
    p1=p1-p2;

n1=10;n2=20;
myFunc2(n1,n2)
print(n1)
print(n2)
# number -- value
# string -- value
#tuple -- value
#list -- ref
#dict -- ref

str1="hello"
str2="hello"
print(id(str1));
print(id(str2));
str2="good"
print(id(str1));
print(id(str2));


def myFunc3(list1):
    list1=("a","b","c")

myList=(10,20,30)
myFunc3(myList);
print(myList)

#default args, positional args, keyword args
def myFunc3(p1,p2=100,p3=1000):
    return p1+p2+p3;

print("hello",end=";")
myFunc3(100,100,100)# positional args
myFunc3(100,100)
myFunc3(100)
myFunc3(p3=1,p2=2,p1=3) # keyword arg
# p1,p3 but not p2
print(myFunc3(100,p3=100)) # positional args and keyword arg 300

#myFunc3(p1=100,p2=100,20)
#myFunc3(100,100,p2=100)
#myFunc3(100,p4=200)

def myFunc4(p1,myList=[]):
    myList.append(p1)
    return myList

print(myFunc4(100))# [100]
print(myFunc4(200))# [100,200];
print(myFunc4(300))# [100,200,300];

def myFunc5(p1,myList=None):
    if(myList is None):
        myList=[]
    myList.append(p1)
    return myList

print(myFunc5(100))#[100]; 
print(myFunc5(200))#[200]; 
print(myFunc5(300))#[300]; 

#None == ud or null

def myFunc6(*p1,sep="$"):
    print(type(p1))#tuple
    print(sep.join(p1))
    # p1 should be an iterable
myFunc6("mumbai","chennai","banglaore",sep="*")#work
myFunc6("mumbai","chennai","banglaore","*")

def myFunc7(*arg,**kwarg):
    print("*"*50)
    print(type(arg))#tuple
    print(arg)
    print(type(kwarg))#dict
    for (k,v) in kwarg.items():
        print(f"{k}:{v}")
    print("*"*50)
#positional args packed into a tuple
#keyword arg packed into a dict

myFunc7(10,20); # p1=(10,20);kwarg={}
myFunc7(empId=101,empName="sara");#p1=(); kwarg={empId:101,empName:"sara"}
myFunc7(10,empId=101);#p1=(10,) kwarg={empId=101}


#tuple1=(10,)
#for i in range(len(tuple1)):
#    print(tuple1(i))

def myFunc8(*args,**kwargs):
    print(kwargs.get("sep","$").join(args))
    
myFunc8("mumbai","chennai","banglaore",sep="*")#work
myFunc8("mumbai","chennai","banglaore")

length=100;
def myFunc10(p1):
    global length
    length=1000;# trying to change the value of the global var or declaring a local var
    print(f"length = {length}")# local var

myFunc10(1);
print(f"Global var Length: {length}")#1000

#closure function
def myFunc9(p1):
    def innerFunc():
        print(__name__)
        print(id(innerFunc))
        #p1=19 # declaring a local var also called as p1
        #p1+=1
        print("Closure function result"+str(p1));# access the value p1
    return  innerFunc;

f1=myFunc9(100);# freeze the memory location of p1
print(id(f1))

f1();#100 ; 
del f1;
print("*"*40)
f2=myFunc9(100)
print(id(f2))
#del p1# error
#performance --- bad practice

def myFunc10(func1):
    def innerFunc(*args,**kwargs):
        return func1(*args,**kwargs).upper()
    return innerFunc

def sayHello(name,salutation):
    return("hello "+salutation+name)

sayHello=myFunc10(sayHello);
res=sayHello("anju",salutation="Ms.");#pack all the positional args into a tuple
print(res);

def sayBye():
    return "bye"

# myFunc10 is adding some functionality to sayHello
#myFunc10 can be applied to multiple functions



sayBye=myFunc10(sayBye)
print(sayBye());



