print("Welcome cgi")

tuple1=("cc","dc","cod","wallet")

print(tuple1);
for i in range(len(tuple1)):
    print(tuple1[i].capitalize())

#tuple1[0]="credit card "

tuple2=tuple(["apple","banana","mangoes"])
print(tuple2)

tuple3=tuple1+tuple2
print(tuple3)

# slicing :  in *

tuple4=(10+10,)
print(type(tuple4))

#cmp(2.x), max,min,len

tuple1=(10,20,30)
tuple2=(25,10,"hello")
print(len(tuple1))
del tuple1
#print(tuple1)

list1=[10,20,30,40,50]
del list1[2]
print(list1)

i,j,*k=(10,20)
print(i)
print(j)
print(k);#list
print(type(k))

a,b,*m1,i,j=(1,2,3,4,5,6,7,8,9,10);
print(m1)
print(i)
print(j)



#int i,k,j=10;
#keys -- unique, immutable data type(string,number,tuple);
#values -- same; mutable /immutable data type
dict1={"empId":101,"empName":"sara","salary":879}
dict1["empId"]=777;

del dict1["salary"]
print(dict1)
dict1["deptId"]="d1"
dict1["location"]=None;
print(dict1)
print(len(dict1));

#iteration items(),keys(),values()

for key in dict1.keys():
    print(f"{key}:{dict1[key]}",end="&")
print()

for value in dict1.values():
    print(value)
print()
for (k,v) in dict1.items():
    print(f"{k}:{v}") 

dict2=dict1.copy();# shallow copy

# clear() -- remove all items from the dict

#fromkeys()

myTuple=("bookId","bookName","author","bookId")
bookDict=dict.fromkeys(myTuple,None);
print(bookDict);

# get()
empId=dict1.get("empId");
print(empId)

aadhaarNo=dict1.get("aadhaarNo","NA");
print(aadhaarNo)

flag="aadhaarNo" in dict1.keys()
print(flag)

dict2={"empId":101,("firstName","lastName"):"sara"}
print(dict2)

#setdefault
dict1.setdefault("empId",333);#ignored
dict1.setdefault("bankAccountno",3456789)
print(dict1)

dict1["empId"]=555;
dict1.update(dict2);
print(dict1)

#import json and store it in python in dict 
#clear in tuple -- NA

# convert tuple to list
tuple1=(10,20,30,40);
list1=list(tuple1)
print(list1)

tuple2=tuple(list1)

i,j=(10,20)#unpacking
i=10,20,30,40,50 #packing a tuple
print(i)
print(type(i))

#sets -- unordered ; no duplicates
fruits={"mangoes","oranges","guavas","mangoes"}
print(fruits)
print(len(fruits))

vegetables={};
print(type(vegetables))#dict

vegetables=set();
print(type(vegetables))#set

set1=set("aeiou")
set2=set("abcdefghijklmno")

#complex number 5i+6
#number -- int,float,complex



