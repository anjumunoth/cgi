console.log("hello")

// strongly typed language

var i:number =10;
console.log(i);
//i="hello";
// number, string,boolean

var str1:string = "hello";
var isPresent:boolean=true;

var arr1:number[]=[1,2,3];

// object
var obj:object={"empId":101,"empName":"sara"}
// camel case
console.log(obj["empId"])

console.log("Obj values"+obj)// not print the individual fields
console.log("Obj values",obj)//  print the individual fields

//any
var j:any;
j=10
j="hello"
j=true
j=[1,2,3]
var k:any[]=[1,"hello",true]

function myFunc(p1:number,p2:string):string
{
    return p1+p2;//concatenation
   
}

// anonymous function
var f1:Function=function (p1:number,p2:number):number
{
    return p1+p2+101
}
var res:number=f1(10,20)
var res1:string=f1(10,20)
console.log(res1)

i=10;
//var str2:string=10;// integer constant
var str2:string=i.toString();

//object with functions
var empObj:object={
    empId:101,
    empName:"sara",
    printDetails:function(){
        console.log(this.empId)
        console.log(this.empName)
    }
}

console.log(empObj["empId"])
empObj["empName"]="jack"
empObj["printDetails"]()

var empObj1:any={
    empId:101,
    empName:"sara",
    printDetails:function(){
        console.log(this.empId)
        console.log(this.empName)
    }
}
console.log(empObj1.empId)
empObj1.printDetails();

class Employees
{
    public empId:number;
    private empName:string;
    private salary:number;
    constructor(eId:number,empName:string)
    {
        this.empId=eId;
        this.empName=empName;
    }
    
}

var eObj:Employees=new Employees(101,"sara")
console.log(eObj.empId)

// inheritance
class Base{
    height:number;
    width:number;
    constructor(p1,p2)
    {
        this.height=p1;
        this.width=p2;
    }
    printDetails(){
        console.log(this.width)
        console.log(this.height)
    }
}

class Derived1 extends Base
{
    length:number;
    constructor(p1,p2,l:number)
    {
        super(p1,p2);
        this.length=l;
        console.log("Called constructor")
    }
    printDetails()
    {
        super.printDetails();
        console.log(this.length)
    }
}
//overloading -- no
//overriding  --yes

var dObj:Derived1=new Derived1(10,20,30);
dObj.printDetails()// 10,20,30

//interfaces

interface I1
{
    area:number;
    display:Function;
}

class Square extends Base implements I1
{
    area:number;
    constructor()
    {
        super(10,20);
        this.area=0;
    }
    display(){
        this.area=this.height*this.width
        console.log("area",this.area);
    }
}

// var , let,const
//var -- function scope; redeclare in the same scope
//let -- block scope; cannot redeclare in the same scope

var i1:number=10;
var i1:number=100;
let i2:number;
//let i2:number;

const PI=3.14
//PI=3.142178;
// linting -- rules in typescript
const myObj={empId:101,empName:"sara"}
//myObj={empId:101,empName:"sara"};
myObj["empId"]=102;
console.log(myObj);//102,sara


// reference , copy, deep copy

//ES6 features
empObj={
    empId:101,
    empName:"sara",
    printDetails:function(){
        console.log(this.empId)
        console.log(this.empName)
    }
}

// reference

var empRef=empObj;
empRef["empId"]=777;
console.log("EmpObj",empObj)
console.log("EmpRef",empRef)

//copy  es6
empObj={
    empId:101,
    empName:"sara",
    printDetails:function(){
        console.log(this.empId)
        console.log(this.empName)
    }
}
var empCopy={...empObj}
empCopy["empId"]=777;
console.log("EmpObj",empObj)
console.log("EmpCopy",empCopy)

var empWithAddedProps={...empObj,deptId:"D1"}
console.log("empWithAddedProps",empWithAddedProps)

var empWithAddedProps1={...empObj,empName:"harry"}// 2 properties
console.log("empWithAddedProps1",empWithAddedProps1)
// overwritten when the field name is same
var empWithAddedProps2={empName:"harry",salary:5678,...empObj}// 2 properties
console.log("empWithAddedProps1",empWithAddedProps2)//{empId:101,empName:"sara",salary:5678}

// spread operator with an array

var arr2:number[]=[1,2,3,4,5]
var arrCopy:number[]=[...arr2];
var arrCopyWithAdd:number[]=[...arr2,40]
console.log(arr2)
console.log(arrCopy)
console.log(arrCopyWithAdd)

// destructuring of object/array

// array -- position
var [first: number,second: number]=arr2
// var first=arr2[0],second=arr[1]
var [p1,,p2]=arr2;
console.log(p1)// 1
console.log(p2)//3
empObj={
    empId:101,
    empName:"sara",
    printDetails:function(){
        console.log(this.empId)
        console.log(this.empName)
    }
}
var eObj:Employees=new Employees(101,"sara")
var {empId}=eObj;
console.log(empId);//101










