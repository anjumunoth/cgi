var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
console.log("hello");
// strongly typed language
var i = 10;
console.log(i);
//i="hello";
// number, string,boolean
var str1 = "hello";
var isPresent = true;
var arr1 = [1, 2, 3];
// object
var obj = { "empId": 101, "empName": "sara" };
// camel case
console.log(obj["empId"]);
console.log("Obj values" + obj); // not print the individual fields
console.log("Obj values", obj); //  print the individual fields
//any
var j;
j = 10;
j = "hello";
j = true;
j = [1, 2, 3];
var k = [1, "hello", true];
function myFunc(p1, p2) {
    return p1 + p2; //concatenation
}
// anonymous function
var f1 = function (p1, p2) {
    return p1 + p2 + 101;
};
var res = f1(10, 20);
var res1 = f1(10, 20);
console.log(res1);
i = 10;
//var str2:string=10;// integer constant
var str2 = i.toString();
//object with functions
var empObj = {
    empId: 101,
    empName: "sara",
    printDetails: function () {
        console.log(this.empId);
        console.log(this.empName);
    }
};
console.log(empObj["empId"]);
empObj["empName"] = "jack";
empObj["printDetails"]();
var empObj1 = {
    empId: 101,
    empName: "sara",
    printDetails: function () {
        console.log(this.empId);
        console.log(this.empName);
    }
};
console.log(empObj1.empId);
empObj1.printDetails();
var Employees = /** @class */ (function () {
    function Employees(eId, empName) {
        this.empId = eId;
        this.empName = empName;
    }
    return Employees;
}());
var eObj = new Employees(101, "sara");
console.log(eObj.empId);
// inheritance
var Base = /** @class */ (function () {
    function Base(p1, p2) {
        this.height = p1;
        this.width = p2;
    }
    Base.prototype.printDetails = function () {
        console.log(this.width);
        console.log(this.height);
    };
    return Base;
}());
var Derived1 = /** @class */ (function (_super) {
    __extends(Derived1, _super);
    function Derived1(p1, p2, l) {
        var _this = _super.call(this, p1, p2) || this;
        _this.length = l;
        console.log("Called constructor");
        return _this;
    }
    Derived1.prototype.printDetails = function () {
        _super.prototype.printDetails.call(this);
        console.log(this.length);
    };
    return Derived1;
}(Base));
//overloading -- no
//overriding  --yes
var dObj = new Derived1(10, 20, 30);
dObj.printDetails(); // 10,20,30
var Square = /** @class */ (function (_super) {
    __extends(Square, _super);
    function Square() {
        var _this = _super.call(this, 10, 20) || this;
        _this.area = 0;
        return _this;
    }
    Square.prototype.display = function () {
        this.area = this.height * this.width;
        console.log("area", this.area);
    };
    return Square;
}(Base));
// var , let,const
//var -- function scope; redeclare in the same scope
//let -- block scope; cannot redeclare in the same scope
var i1 = 10;
var i1 = 100;
var i2;
//let i2:number;
var PI = 3.14;
//PI=3.142178;
// linting -- rules in typescript
var myObj = { empId: 101, empName: "sara" };
//myObj={empId:101,empName:"sara"};
myObj["empId"] = 102;
console.log(myObj); //102,sara
// reference , copy, deep copy
//ES6 features
empObj = {
    empId: 101,
    empName: "sara",
    printDetails: function () {
        console.log(this.empId);
        console.log(this.empName);
    }
};
// reference
var empRef = empObj;
empRef["empId"] = 777;
console.log("EmpObj", empObj);
console.log("EmpRef", empRef);
//copy  es6
empObj = {
    empId: 101,
    empName: "sara",
    printDetails: function () {
        console.log(this.empId);
        console.log(this.empName);
    }
};
var empCopy = __assign({}, empObj);
empCopy["empId"] = 777;
console.log("EmpObj", empObj);
console.log("EmpCopy", empCopy);
var empWithAddedProps = __assign(__assign({}, empObj), { deptId: "D1" });
console.log("empWithAddedProps", empWithAddedProps);
var empWithAddedProps1 = __assign(__assign({}, empObj), { empName: "harry" }); // 2 properties
console.log("empWithAddedProps1", empWithAddedProps1);
