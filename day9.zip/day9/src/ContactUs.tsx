import * as React from 'react';

export interface IContactUsProps {
}

export interface IContactUsState {
}

export default class ContactUs extends React.Component<IContactUsProps, IContactUsState> {
  constructor(props: IContactUsProps) {
    super(props);

    this.state = {
    }
  }

  public render() {
    return (
      <div>
        <h1>ContactUs</h1>
      </div>
    );
  }
}
