import { resolve } from "dns"

function myEvenNumberFunc(p1)
{
        if(p1%2 ==0)
            return Promise.resolve(`${p1} is an even number`)
        else
            return Promise.reject(`${p1} is an odd number`)

    
}
myEvenNumberFunc(10)
.then((data)=>{
    console.log(data)
})
.catch((err)=>{
    console.log(err)

})


function myEvenNumberFunc2(p1)
{
    return new Promise((resolve,reject)=>{
        setTimeout(()=>{
            if(p1 == 0)
            {
                reject(`${p1} cant be zero`)
            }
            if(p1%2 ==0)
                resolve(`${p1} is an even number`)
            else
                if(p1 %3 ==0)
                {
                    resolve(`${p1} is atleast divisible by 3`)
                }
                else
                {
                    reject(`${p1} is an odd number`)
                }

        },3000)

    })
}
myEvenNumberFunc2(101)
.then((data)=>{
    return data.toUpperCase()
    // return something from a then --> return a promise which is resolved
})
.then((upperCaseData)=>{
    console.log(upperCaseData)
})
.catch((err)=>{
    console.log(err)
    return Promise.reject(err.substr(0,4));// return a promise which is rejected

})
.then((msg)=>{
    console.log(msg)
})
.catch((subStr1)=>{
    console.log("In the catch"+subStr1)
})

/*
Promise -- proxy for a value from a async op
3 stages
pending  -- async op has not got completed
resolve(fulfilled) -- async op has got completed successfully
reject -- async op has failed

promise --> pending --> resolve or reject 

promise resolve -- success -- data from async op
promise reject -- with the error

be notified promise 

select * from empId where empId =101; get data resolve; no rec -- reject the promise
insert -- successful -- resolve ; failure -- reject


*/