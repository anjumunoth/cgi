import * as React from 'react';
import {RouteComponentProps,Link,Route,Redirect} from "react-router-dom"
import AboutUs from './AboutUs';


export interface ICoursesProps extends RouteComponentProps{
}

export interface ICoursesState {
}

export default class Courses extends React.Component<ICoursesProps, ICoursesState> {
  constructor(props: ICoursesProps) {
    super(props);

    this.state = {
    }
  }

  public render() {
      var baseUrl=this.props.match.path;
      var angularUrl=baseUrl+"/Angular"
      var reactUrl=baseUrl+"/React"
      var pythonUrl=baseUrl+"/Python"
      
    return (
      <div>
          <div>
              <ul>
                  <li>
                      <Link to={angularUrl}>Angular</Link>
                  </li>
                  <li>
                      <Link to={reactUrl}>React</Link>
                  </li>
                  <li>
                      <Link to={pythonUrl}>Python</Link>
                  </li>
              </ul>
          </div>
          <div>

              <Route path={angularUrl}  render={()=>{
                  return (<h1>Angular Component</h1>)
              }} />
              <Route path={reactUrl} render={()=>{
                  return (<h1>React Component</h1>)
              }} />
              <Route path={pythonUrl} render={()=>{
                  return (<h1>Python Component</h1>)
              }} />
              <Redirect path={baseUrl} to={angularUrl}/> 
          </div>
        
      </div>
    );
  }
}
