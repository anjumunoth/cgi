import * as React from 'react';
import axios from "axios"

export interface IAppProps {
}

export interface IAppState {
}

export default class AxiosExample extends React.Component<IAppProps, IAppState> {
  constructor(props: IAppProps) {
    super(props);

    this.state = {
    }
  }
  componentDidMount()
  {
      //CORS
    var serverUrl="https://localhost:5000/employees"
    axios.get(serverUrl)
    .then((response)=>{
        console.log(response)
    })
    .catch((err)=>{
        console.log(err)
    })
  }

  public render() {
    return (
      <div>
        <h1> Axios Example</h1>
      </div>
    );
  }
}
