import * as React from 'react';
import {RouteComponentProps} from "react-router-dom"

export interface IBooksProps extends RouteComponentProps {
    
}

export interface IBooksState {
}

export default class Books extends React.Component<IBooksProps, IBooksState> {
  constructor(props: IBooksProps) {
    super(props);

    this.state = {
    }
  }

  public render() {
      var paramObj:any=this.props.match.params ;
      var bookName=paramObj?paramObj.bookName:"Unknown"
      var routeStateObj=this.props.location.state;
      var bookObj:any=routeStateObj?routeStateObj:{};

      console.log("Props in Books",this.props)
    return (
      <div>
        <h1> Books Component</h1>
        <h3> Book Name: {bookName}</h3>
        <h3> Cost of the book: {bookObj.cost}</h3>
        <input type="button" value="Go Back" onClick={()=>{
            this.props.history.go(-2)
            //go to home page
            //this.props.history.push("/")
        }}/>
      </div>
    );
  }
}
