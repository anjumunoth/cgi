import * as React from 'react';
import {Link} from "react-router-dom"
import "./Menu.css"

export interface IAppProps {
}

export default class App extends React.Component<IAppProps> {
  public render() {
    return (
      <div>
        <ul>
          <li>
              <Link to="/employees" >Employees</Link>
          </li>
          <li>
              <Link to="/aboutus" >AboutUs</Link>
          </li>
          <li>
              <Link to="/contactus" >ContactUs</Link>
          </li>
          <li>
              <Link to="/courses" >Courses</Link>
          </li>
        </ul>
      </div>
    );
  }
}
