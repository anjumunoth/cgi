import * as React from 'react';
import { RouteComponentProps } from 'react-router-dom';

export interface IAboutUsProps extends RouteComponentProps {
}

export interface IAboutUsState {
}

export default class AboutUs extends React.Component<IAboutUsProps, IAboutUsState> {
    nameRef:any;
  constructor(props: IAboutUsProps) {
    super(props);
    this.nameRef=React.createRef();
    this.state = {
    }
  }
  gotoContactusEventHandler=()=>{
      // route to /contactus
      this.props.history.push("/contactus");

  }
  sendDataEventHandler=()=>{
      var bookName=this.nameRef.current.value;
      //books/alchemist
      var bookObj={bookName:bookName,cost:bookName.length*10}
      this.props.history.push("/books/"+bookName,bookObj);
     
  }
  public render() {
      console.log("Props",this.props)
    return (
      <div>
        <h1>AboutUs</h1>
        <input type="button" value="Go to Contact us" onClick={this.gotoContactusEventHandler}/>
        <br/>
        <input type="text" ref={this.nameRef}/>
        <input type="button" value="Send data to Books" onClick={this.sendDataEventHandler}/>
      </div>
    );
  }
}
