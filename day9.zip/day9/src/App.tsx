import React from 'react';
import logo from './logo.svg';
import './App.css';
import Home from "./Home"
import Menu from "./Menu"
import Footer from "./Footer"
import Header from "./Header"
import Messages from "./Messages"

import { BrowserRouter } from "react-router-dom";
import Main from './Main';

function App() {
  return (
    <div >

      <Header></Header>
      <BrowserRouter>
        <Menu></Menu>
        <Main></Main>
      </BrowserRouter>
      <Footer></Footer>
    </div>
  );
}

export default App;
