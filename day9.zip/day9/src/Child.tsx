import React,{useState,useEffect} from 'react';

interface IChildProps {
    countryName:string
}

const Child: React.FunctionComponent<IChildProps> = (props) => {
    var objArr=[{countryName:"India",capital:"New Delhi"},{countryName:"Australia",capital:"Sydney"},{countryName:"US",capital:"New York"}]
    var [capital,setCapital]=useState("")
    
    useEffect(() => {
        console.log("GetDerivedStateFromProps")
      var obj=objArr.find(item => item.countryName == props.countryName)
      if(obj)
      {
          setCapital(obj.capital)
      }
      else
      {
          setCapital("NA")
      }
    }, [props.countryName])


  return(
      <div>
          <h1> Props Country Name : {props.countryName}</h1>
          <h1> Capital : {capital}</h1>
      </div>
  ) ;
};

export default Child;
