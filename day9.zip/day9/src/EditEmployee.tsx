import * as React from 'react';

export interface IAppProps {
    selectedEmp:any;
    sendUpdatedEmp:any;
    
}

export interface IAppState {
    selectedEmp:any;
    empName:string;
    salary:string;
    
}

export default class App extends React.Component<IAppProps, IAppState> {
    empNameRef:any;
    salaryRef:any;
  constructor(props: IAppProps) {
    super(props);

    this.state = {
        selectedEmp:this.props.selectedEmp,
        empName:this.props.selectedEmp.empName,
        salary:this.props.selectedEmp.salary
    
    }
    this.empNameRef=React.createRef();
    this.salaryRef=React.createRef();
  }

  static getDerivedStateFromProps(nextProps: any, prevState: any) {
    if(nextProps.selectedEmp.empId != prevState.selectedEmp.empId)
    {
        return {...prevState,selectedEmp:nextProps.selectedEmp,empName:nextProps.selectedEmp.empName,salary:nextProps.selectedEmp.salary}
    }
    else
        return {...prevState};
  } 

  confirmDetailsEventHandler=()=>{
            var updatedEmp={
            empId:this.state.selectedEmp.empId,
            empName:this.empNameRef.current.value,
            salary:parseInt(this.salaryRef.current.value)
        }
        this.setState({empName:this.empNameRef.current.value,salary:this.salaryRef.current.value})
        // send it to parent component
        //triggering the event
        this.props.sendUpdatedEmp(updatedEmp);
    
  }
  nameChangeEventHandler=(event:any)=>{
      this.setState({empName:event.target.value})

  }
  salaryChangeEventHandler=(event:any)=>{
      this.setState({salary:event?.target.value})
  }
  componentWillUnmount()
  {
      alert("Component will be unmounted")
  }
  public render() {
      console.log("Props in Edit Employee",this.props)
      var {selectedEmp}=this.props;
      
    return (
      <div>
        <form>
            <table className="table">
                <tbody>
                <tr>
                    <td>
                        <label>Employee Id</label>
                    </td>
                    <td>
                        <label>{selectedEmp.empId}</label>
                    </td>
                </tr>
                <tr>
                    <td>
                        <label>
                            Employee Name
                        </label>
                    </td>
                    <td>
                        <input type="text" value={this.state.empName}
                         ref={this.empNameRef}
                         onChange={this.nameChangeEventHandler}/>
                    </td>
                </tr>
                <tr>
                    <td>
                        <label>
                            Salary
                        </label>
                    </td>
                    <td>
                        <input type="text" value ={this.state.salary} ref={this.salaryRef}
                        onChange={this.salaryChangeEventHandler}/>
                    </td>
                </tr>
                <tr>
                    <td>
                        <input type="button" value="Confirm" className="btb btn-warning text-primary" onClick={this.confirmDetailsEventHandler}
                        />
                    </td>
                    <td></td>
                </tr>
                </tbody>
            </table>
        </form>
      </div>
    );
  }
}
