import * as React from 'react';

export interface IAppProps {
    onAddEmployee:any
}

export interface IAppState {
    empId:string;
    empName:string;
    salary:string;

}

export default class App extends React.Component<IAppProps, IAppState> {
    empNameRef:any;
    salaryRef:any;
    constructor(props: IAppProps) {
        super(props);

        this.state = {
            empId:"",
            empName:"",
            salary:""
        }
        this.empNameRef=React.createRef();
        this.salaryRef=React.createRef()
    }
    employeeIdChangeEventHandler=(event:any)=>{
        this.setState({empId:event.target.value})
        console.log(event.target.value)
    }
    confirmDetailsEventHandler=()=>{
        this.setState({empName:this.empNameRef.current.value,
            salary:this.salaryRef.current.value
        })
        var tempEmp={
            empId:parseInt(this.state.empId),
            empName:this.empNameRef.current.value,
            salary:parseInt(this.salaryRef.current.value)
        }
        console.log("New employee details",tempEmp)
        this.props.onAddEmployee(tempEmp)
    }
    public render() {
        return (
            <div>
                <h1> Add Employee Component</h1>
                <form>
                    <div className="container bg-warning text-primary ">
                        <div className="row m-2">
                            <label className="col-2">Employee Id</label>
                            <input type="text" className="col-4" onChange={this.employeeIdChangeEventHandler}/>
                        </div>
                        <div className="row m-2">
                            <label className="col-2">Employee Name</label>
                            <input type="text" className="col-4" ref={this.empNameRef}/>
                        </div>
                        <div className="row m-2">
                            <label className="col-2">Salary</label>
                            <input type="text" className="col-4" ref={this.salaryRef}/>
                        </div>
                        <div className="row m-2">
                            <input type="button" value="Confirm Details" 
                            className="btn btn-primary col-3 m-3"
                            onClick={this.confirmDetailsEventHandler}
                            />
                            <input type="reset" value="Clear" className="btn btn-primary col-3 m-3"/>
                        </div>
                    </div>
                </form>
                Employee Id {this.state.empId}
                Employee Name {this.state.empName}
            </div>
        );
    }
}
