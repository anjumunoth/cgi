import * as React from 'react';

export interface IAppProps {
}

export default class App extends React.Component<IAppProps> {
  public render() {
    return (
      <div>
        <h1> Footer Component</h1>
      </div>
    );
  }
}
