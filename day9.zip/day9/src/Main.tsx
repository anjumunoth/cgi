import * as React from 'react';
import { Route, Redirect, Switch } from "react-router-dom"
import AboutUs from './AboutUs';
import ContactUs from './ContactUs';
import Home from './Home';
import Books from "./Books"
import Courses from "./Courses"
import HooksExample from "./HooksExample"
import AxiosExample from './AxiosExample';

export interface IAppProps {
}

export interface IAppState {
}

export default class Main extends React.Component<IAppProps, IAppState> {
    constructor(props: IAppProps) {
        super(props);

        this.state = {
        }
    }

    public render() {
        
        return (
            <div>
                <Switch>
                    <Route path="/axiosExample" component={AxiosExample}></Route>
                    <Route path="/hooksExample" component={HooksExample}></Route>
                    <Route path="/aboutus" component={AboutUs}></Route>
                    <Route path="/courses" component={Courses}></Route>
                    <Route path="/books/:bookName?" component={Books}></Route>
                    <Route path="/contactus" component={ContactUs}></Route>
                    <Route path="/employees" component={Home}></Route>
                    <Redirect path="/" to="/employees" exact ></Redirect>
                    <Route render={() => {
                        return (<h1>Page Not Found</h1>)
                    }}></Route>
                </Switch>
            </div>
        );
    }
}
