import  React,{useState,useEffect,useRef} from 'react';
import Child from "./Child"

interface IProps {
}

const HooksExample: React.FunctionComponent<IProps> = (props) => {
    var[name,setName]=useState("");

    var [fullName,setFullName]=useState("")
    var [countryName,setCountryName]=useState("India")
    var [hobbies,setHobbies]=useState(["singing","dancing","cooking"])
    var [currTime,setCurrTime]=useState((new Date()).toString())
    var [feedback,setFeedback]=useState("")

    var emailRef=useRef<HTMLInputElement>(null);
    //can i have multiple useState
    //var res=useState("");var name=res[0];var setName=res[1];
    //setName("ganesh");// infinite loop
    var changeNameEventHandler=(event:any)=>{
        //this.setState({name:event.target.value})
        setName(event.target.value);
        //setName -- update name ; rerender FC
    }
    var chnageCountryEventHandler=(event:any)=>{
        setCountryName(event?.target.value)
    }
    // 2 params ; param1 -- function; param2 -- dependency list or array;optional 
        // componentDidMount
        // empty dependency list --> called once --> after the render 
    useEffect(()=>{
        console.log("ComponentDidMount")
        var clearIntervalId=setInterval(()=>{
            setCurrTime((new Date()).toString())
            // rerender
        },1000)
        return (
            ()=>{
                console.log("ComponentWillUnmount")
                clearInterval(clearIntervalId)
            }
        )
    },[])

    useEffect(()=>{
        return (
            ()=>{
                console.log("This will also be called when component gets unmounted")
            }
        )
    },[])
    // useEffect -- multiple
    //order -- same as i have written
    // modularity -- multiple effects
    // value in the dependency list -- whenever the value in the dependency list changes, the use Effect will be called
    useEffect(()=>{
        console.log("This effect will be called whenever the name changes")
        setFullName("Ms."+name.toUpperCase());
    },[name])

    useEffect(()=>{
        // will be called when either name changes or country name changes
        setFeedback(`${name} loves ${countryName}`)
    },[name,countryName])

     useEffect(()=>{
         // will be called with every render
         //componentDidUpdate
        console.log("oh my god ,, this is a bad practice")
    }) 
    var clickEventHandler=()=>{
        var emailId=emailRef.current?.value
        console.log(emailId)
        //manipulation on emailId
    }
  return(
      <React.Fragment>
          <input type="text"placeholder="Enter the username" onChange={changeNameEventHandler} />
          <input type="text" onChange={chnageCountryEventHandler} value={countryName}/>
          <br/>
          <input type="text" placeholder="Enter the emailid" ref={emailRef}/>
          <input type="button" value="Click" onClick={clickEventHandler}/>
          <p> User name :{name}</p>
          <p> Full Name :{fullName}</p>
          <p>Country Name :{countryName}</p>
          <p> Current Time: {currTime}</p>
          <p> Feedback: {feedback}</p>
          <Child countryName={countryName}></Child>
      </React.Fragment>
  ) ;
};

export default HooksExample;
