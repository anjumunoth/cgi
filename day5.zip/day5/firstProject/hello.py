from flask import Flask
app = Flask(__name__)

@app.route("/")
def hello_cgi():
    return "Hello CGI"

if __name__== "__main__":
    
    app.run()
#PORT -- 5000, localhost