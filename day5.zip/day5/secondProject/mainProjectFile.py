from mypackage import app

