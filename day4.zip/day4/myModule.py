def add(p1,p2):
    print( p1+p2);
def sub(p1,p2):
    print( p1-p2);
def mul(p1,p2):
    print( p1*p2);
def div(p1,p2):
    print( p1/p2);

def __privateFunc(p1,p2):
    print("inside private func")
    print(p1.index(p2));