import myModule;

from myModule3 import convertTupleToList as ctol;
print("Inside module2");
print(dir(myModule))

myModule.add(10,20)
myModule.sub(10,5);
myModule.__privateFunc("happy","a")
print(ctol((1,2,3,4)))


# locate modules
#1. current dir(sub dir)
#2. pythonconvertTupleToList path environment var
# 3.unix default path : /usr/local/lib/python3/ 
#4. error

# sys.path -- module search

#namespace and scope

#local has more than global scope
# global varName
#
#globals() and locals should be called within a func only
#locals() -- return all the names that are local
#globals() -- return all the global names
globalI=1000
def scopeExample():
    i=10;
    j=20;
    print(locals())
    print("Globals:",globals())

scopeExample()
