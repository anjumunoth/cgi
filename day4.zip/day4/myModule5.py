import myModule4 as my4;


# modules are going to cache

my4.add(100,200)
print("In module 5 name ",__name__)

#__main__ is an alias name for the module with which we execute using the python compiler;
