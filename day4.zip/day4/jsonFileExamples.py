# serialisation -- python data --> json data
# deserialisation json --> python data
import json
with open(r"empData.json","r") as filePtr:
    myData=json.load(filePtr);
    
    #print(myData["employees"]);
    empList=myData["employees"]
    for i in range(len(empList)):
        print(empList[i]);




with(open(r"empData.json",mode="r",encoding="utf-8")) as fileptr:
    myData=fileptr.read();
#    print(myData);

restData={"details":[{"address": {"building": "1007", "coord": [-73.856077, 40.848447], "street": "Morris Park Ave", "zipcode": "10462"}, "borough": "Bronx", "cuisine": "Bakery", "grades": [{"date": {"$date": 1393804800000}, "grade": "A", "score": 2}, {"date": {"$date": 1378857600000}, "grade": "A", "score": 6}, {"date": {"$date": 1358985600000}, "grade": "A", "score": 10}, {"date": {"$date": 1322006400000}, "grade": "A", "score": 9}, {"date": {"$date": 1299715200000}, "grade": "B", "score": 14}], "name": "Morris Park Bake Shop", "restaurant_id": "30075445"},
{"address": {"building": "469", "coord": [-73.961704, 40.662942], "street": "Flatbush Avenue", "zipcode": "11225"}, "borough": "Brooklyn", "cuisine": "Hamburgers", "grades": [{"date": {"$date": 1419897600000}, "grade": "A", "score": 8}, {"date": {"$date": 1404172800000}, "grade": "B", "score": 23}, {"date": {"$date": 1367280000000}, "grade": "A", "score": 12}, {"date": {"$date": 1336435200000}, "grade": "A", "score": 12}], "name": "Wendy'S", "restaurant_id": "30112340"},
{"address": {"building": "351", "coord": [-73.98513559999999, 40.7676919], "street": "West   57 Street", "zipcode": "10019"}, "borough": "Manhattan", "cuisine": "Irish", "grades": [{"date": {"$date": 1409961600000}, "grade": "A", "score": 2}, {"date": {"$date": 1374451200000}, "grade": "A", "score": 11}, {"date": {"$date": 1343692800000}, "grade": "A", "score": 12}, {"date": {"$date": 1325116800000}, "grade": "A", "score": 12}], "name": "Dj Reynolds Pub And Restaurant", "restaurant_id": "30191841"},
{"address": {"building": "2780", "coord": [-73.98241999999999, 40.579505], "street": "Stillwell Avenue", "zipcode": "11224"}, "borough": "Brooklyn", "cuisine": "American ", "grades": [{"date": {"$date": 1402358400000}, "grade": "A", "score": 5}, {"date": {"$date": 1370390400000}, "grade": "A", "score": 7}, {"date": {"$date": 1334275200000}, "grade": "A", "score": 12}, {"date": {"$date": 1318377600000}, "grade": "A", "score": 12}], "name": "Riviera Caterer", "restaurant_id": "40356018"},
{"restaurant_id":567,"cuisine":("Chinese","Indian"),"isVeg":False,"coord":None}]}

with(open(r"rests.json",mode="w",encoding="utf-8")) as filePtr:
    json.dump(restData,filePtr,indent=4);

# req json object
# loads --> convert the json obj into python
# handling a post req; json data as part of req
""" jsonObj={
		"empId": 106,
		"empName": "Pran",
		"salary": 4000,
		"deptId":null,
		"hobbies":["singing","dancing","cooking"],
		"isMarried":false
	}
pythonObj=json.loads(jsonObj);
print(pythonObj);# dict
 """

pythonDict={"empId": 106,
		"empName": "Pran",
		"salary": 4000,
		"deptId":None,
		"hobbies":("singing","dancing","cooking"),
		"isMarried":False}
jsonData=json.dumps(pythonDict,indent=4);
print(jsonData)
print(type(jsonData))

#general
#json data -- stringified
#parse the data -- receive the myData
#stringify the data-- sending the myData




