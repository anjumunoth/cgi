class Square:
    def __init__(self,length,**kwargs) -> None:
        #print(kwargs);#dict {base:,height:}
        self.length=length;
        print("Square constructor called")
        super().__init__(**kwargs)

class Triangle:
    def __init__(self,base,height,**kwargs) -> None:#packing
        #print(kwargs)#dict {length:}
        self.base=base
        self.height=height;
        print("Traingle constructor called")
        super().__init__(**kwargs)# spreading of dict
    
    def printDetails(self):
        print(self.base)
        print(self.height);

class Pyramid(Square,Triangle):
    def __init__(self, base,pyramid_length,**kwargs) -> None:
        #print(kwargs)
        print("Pyramid constructor called")
        self.pyramid_length=pyramid_length;
        super().__init__(base=base,**kwargs)
        #super().__init__(base=base,length=300,height=200)
    
    def printDetails(self):
        super().printDetails()
        

obj=Pyramid(100,400,height=200,length=300)#pyramid square triangle
print(obj.length)
print(obj.height)
print(obj.base)
print(obj.pyramid_length)
print(Pyramid.mro());

class Example:
    pass;

print(Example.mro())

def myFunc2(p2,p3):
    print("In func2",type(p2));
    print("In func2",p2)
    print("In func2",p3)

def myFunc1(p1,**kwargs):
    print(p1)
    print(kwargs);
    myFunc2(**kwargs)#unpacking the dict

#myFunc1(100,p2=200,p3=300)
myFunc1(p1=100,p2=200,p3=300)



# ambiguity in function call -->mro-->first function will get excuted --