import myModule2;
def add(p1,p2):
    print( p1+p2);
print("Inside module4");
add(2,3)
if __name__=="__main__":
    add(10,20);

print("In module 4 name ",__name__)
