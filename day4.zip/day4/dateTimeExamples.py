import datetime ;
print(dir(datetime));

datetime_obj=datetime.datetime.now();
print(datetime_obj);

date_obj=datetime.date.today();
print(date_obj)

christmas=datetime.date(2021,12,25);
print(christmas);
print(type(christmas))
newYear=datetime.date(2021,1,1)

# timestamp --> date
new_date=datetime.date.fromtimestamp(43567678)
print(new_date)
print(new_date.year)

new_time=datetime.time(18,51,56);
print(new_time)
print(new_time.minute)

# timedelta
t1=datetime.datetime(2021,2,24)
t2=datetime.datetime(2020,2,24)

t3=t2-t1;
print(t3)
print(type(t3))

t4=datetime.timedelta(weeks=2,days=5,hours=1,seconds=32);
t5=datetime.timedelta(days=4,hours=11,minutes=4,seconds=54);
t6=t4-t5
print(t4);
print(t5)
print(t6)
print(t6.total_seconds());

# format the dates in a custom format
#strftime
formattedStr1=christmas.strftime("%A, %d-%m-%Y")
print(formattedStr1)

res=datetime.datetime.strptime("21 June 2018","%d %B %Y")
print(res)