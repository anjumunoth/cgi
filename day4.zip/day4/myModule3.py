def convertTupleToList(t1):
    myList=list(t1);
    myList.extend([5,6,7]);
    return myList;
