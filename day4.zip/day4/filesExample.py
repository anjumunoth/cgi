with(open(r"text1.txt",mode="w",encoding="utf-8")) as fileptr:
    fileptr.write("my first text file")
    fileptr.write("\nthis is a file written using python\n")
    fileptr.write("New line of text")
    fileptr.writelines(["\nChennai","\nmumbai"])

with(open(r"text1.txt",mode="r+",encoding="utf-8")) as fileptr:
    fileptr.seek(0)
    print(fileptr.read(5));
    print(fileptr.read());
    fileptr.seek(0);
    for line in fileptr:
        print(line,end=" ")
    fileptr.seek(0);
    print(fileptr.readline())
    print(fileptr.tell())
    fileptr.read();
    print("End of file",fileptr.tell())
    currentEod=fileptr.tell();
    fileptr.seek(currentEod);
    fileptr.write("This is the last line");

class A():
    def __init__(self) -> None:
        print("A constructor called")
        self.num2=1000
    def sayHello(self):
        print("hello",self.num2)

class B(A):
    def __init__(self) -> None:
        self.num1=100
        self.num2=2000;#specific field to B or is the inherited field from A

obj=B();
print(obj.num1);
obj.sayHello() # 2000
# super constructor call not needed
#1. obj.field name -- assignment
#2. add fields in the fly


#java 
#super() -- error
# c++


