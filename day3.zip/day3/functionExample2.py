def numberOfOccurences(str1,substr1):
    pos=str1.find(substr1);
    ctr=0;
    while pos!=-1:
        ctr+=1;
        pos=str1.find(substr1,pos+1)
    return ctr;

def ignorecase(func1):
    def innerFunc(str1,substring1):
        str1=str1.upper()
        substring1=substring1.upper()
        return func1(str1,substring1);
    return innerFunc;

res=numberOfOccurences("To be or not to be is a question","to");
print("Result",res)

numberOfOccurences=ignorecase(numberOfOccurences);
res=numberOfOccurences("To be or not to be is a question","to");
print("Result after applying ignore case",res)

#decorators
# custom decorators

def changeToUpper(func1):
    def innerFunc(*args,**kwargs):
        return func1(*args,**kwargs).upper()
    return innerFunc

def printStar(func1):
    def innerFunc(*args,**kwargs):
        print("*"*50);
        func1(*args,**kwargs)
        print("*"*50);
    return innerFunc

def printDollar(func1):
    def innerFunc(*args,**kwargs):
        print("$"*50);
        func1(*args,**kwargs)
        print("$"*50);
    return innerFunc


@changeToUpper
def sayHello(name,salutation):
    return("hello "+salutation+name)

print(sayHello("anju","Ms."))
print(sayHello(name="sara",salutation="Ms."))
print(sayHello("ganesh",salutation="Mr."))

@printStar
@printDollar
def sayBye():
    print("Bye");

sayBye();
#***$$$Bye$$$***; work

#printStar(printDollar(sayBye))

def sayWelcome():
    print("welcome")


sayWelcome();

