#open, perform the operation
#open -- path to file,mode,encoding
#mode -- r(default),w,a,x,t(default),b,+  r+b 

try:
    with open(r"text1.txt",mode="r",encoding="utf-8") as f:
    # perform the op
        print(f.readline())
except Exception as e:
    print("Error",e);
finally:
  pass;

   # getterfn, setter
   # obj.getSalary()
   # obj.setSalary(100)
   # encapsulation, abstraction
   # obj.salary=100;
   # print(obj.salary) 