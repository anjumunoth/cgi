import math;
class Polygon:
    ctr=0;#class member
    def __init__(self,numberOfSides):
        self.numberOfSides=numberOfSides;
        self.sides=[]# instance member
        Polygon.ctr+=1;#global and local; searching for a local var ctr
    
    def getInput(self):
        #list comprehension
        self.sides=[int(input("Enter the side")) for x in range(self.numberOfSides)]

    def printDetails(self):
        print(self.sides);
    
traingle=Polygon(3);
traingle.getInput();# Polygon.getInput(traingle)
traingle.printDetails();
print("Ctr= ",Polygon.ctr)
mysquare=Polygon(2);
mysquare.getInput();
mysquare.printDetails()
print("Ctr= ",Polygon.ctr)
#python -- can add var anytime
traingle.area=0;
Polygon.ctr=100;
print("Ctr= ",Polygon.ctr)
print("Ctr using object",mysquare.__class__.ctr)

mysquare.ctr=700;# adding a new member called as ctr
print("Ctr",Polygon.ctr)#100

#constructor  -- optional,overloading --- no; overwriting

class Employee:
    def inputData(self,eId,eName):
        self.empId=eId;
        self.empName=eName;

sara=Employee();
sara.inputData(101,"sara");#Employee.inputData(sara,101,"sara")
print(sara.empId)

class Books:
    def __init__(self,bId,bName) -> None:
        self.bookId=bId;
        self.bookName=bName
    def __init__(self) -> None:
        self.bookId=1;
        self.bookName=""
    

book1=Books();#Books.__init__(book1)
print("Book1 details",book1.bookId)

#book2=Books(2,"alchemist")
#print("Book2 details",book2.bookId)

# implement like constructor overloading

class User:
    def __init__(self,name) -> None:
        self.name=name;
    
    @classmethod
    def mergeName(cls,firstName,lastName):
        myName=firstName+lastName;
        tempUser=cls(myName);# calling the constructor; User.__init__(tempUser,myName)
        return tempUser

    @classmethod
    def extractName(cls,dict1):
        return User(dict1["name"])

    
user2=User.mergeName("ms","dhoni")
print(user2.name);#msdhoni

user3=User.extractName({"empId":101,"name":"sara"})
print(user3.name)

#destructor

class Emp:
    def __del__(self):
        print("Destructor called")
        
def myFunc1():
    emp1=Emp()

myFunc1()

#abstraction
#private,public, protected
class Emp:
    def __init__(self,eId,eName,salary) -> None:
        self.empId=eId
        self.empName=eName;
        self.__salary=salary; # private var
    def printDetails(self):
        print("EmpId",self.empId)
        print("Salary",self.__salary)# private var 
    
    def changeSalary(self,newSalary):
        self.__salary=newSalary;

    

emp1=Emp(101,"sara",567);
emp1.printDetails();
print("EmpId",emp1.empId);
#print("salary",emp1.__salary);#error
emp1.__salary=1000;# adding a public new field bad practice
print("salary",emp1.__salary);#1000; obj.public fields
emp1.printDetails();#567  
emp1.changeSalary(333);#private var
emp1.printDetails()#101;333

#class members
# refer to ctr in Polygon

#static functions
# one instance for all the objects; Classname.staticFunc();
# cannot be access the instance var
# can access the class var
# can take in 0 or more params
# utility functions -- logic pertaining to a particular class
# will not get a ref to the class ; not an alternative to the constructor

class Student:
    @staticmethod
    def isFullName(name):
        list1=name.split(" ")
        return (len(list1) > 1)

print(Student.isFullName("anju"))#false
print(Student.isFullName("anju munoth"))#true

#deepcopy
import copy;
list1=copy.deepcopy([10,20,30,["a","b"]])
# deepcopy -- static ; classname : copy
# copy.deepcopy
#polymorphism
# static ; dynamic polymorphism
# overloading; overriding
# overloading
#constructor overloading -- no
#function overloading -- no

#overriding
 #same function name; same param sign

 # class inherit object

class Square:
    def __init__(self,side) -> None:
        self.side=side
    #override the str 
    def __str__(self) -> str:
        str1=f"Side :{self.side}"
        return str1
    def __add__(self,other):
        tempObj=Square(self.side+other.side)
        return tempObj

    def __lt__(self,other):
        return self.side < other.side

sqObj1=Square(20);
print(sqObj1)
sqObj2=Square(30);
print(sqObj2)
sqObj3=sqObj1+sqObj2;#not work
print(sqObj3)

if(sqObj1<sqObj2):
    print("square2 is bigger")
else:
    print("square1 is bigger")



# inheritance;
# single, multiple,multi level, hybrid

class Shape:
    def __init__(self,numberOfSides) -> None:
        self.numberOfSides=numberOfSides;
        self.sides=[];
    def inputValues(self):
        self.sides=[float(input("Enter the side")) for x in range(self.numberOfSides)]
    #abstract function
    def calcArea(self):
        pass;
    def __str__(self):
        return (f"Sides :{self.sides}")

class Cylinder(Shape):
    def __init__(self, numberOfSides) -> None:
        #super().__init__(numberOfSides)
        Shape.__init__(self,numberOfSides);
        self.volume=0;
    def calcArea(self):
        area=1;
        for i in range(self.numberOfSides):
            area*=self.sides[i];
        return area*math.pi;
        

cylinderObj=Cylinder(2);
cylinderObj.inputValues();
print(f"Area ={str(cylinderObj.calcArea())}")

#multiple inheritance

class Base1:
    def __init__(self,number1) -> None:
        self.number1=number1;
    def func1(self):
        print("Base1 func1");


class Base2:
    def __init__(self,number2) -> None:
        self.number1=number2;
    def func1(self,p1):
        print("Base2 func1",p1);


class Derived(Base1,Base2):
    def __init__(self,number1,number2,number3):
        Base1.__init__(self,number1)
        Base2.__init__(self,number2)
        self.number3=number3;
    
    def func1():
        #what should be the function sign
        # how to call the function
        pass

    def printDetails(self):
        Base1.func1(self);
        Base2.func1(self,"hello");
        print("Values in base1")
        print("Values in base2")
    
obj1=Derived(1,2,3);
print(obj1.number1)
#print(obj1.number2)
print(obj1.number3)

# depth first search left to right mor

#@property

class Employee:
    def __init__(self,eId,eName,salary,ac) -> None:
        self.empId=eId
        self.empName=eName;
        self.__salary=salary; # private var
        self.__aadhaarCard=ac;
    def printDetails(self):
        print("EmpId",self.empId)
        print("Salary",self.__salary)# private var 
    
    @property
    def aadhaarcard(self):
        return self.__aadhaarCard
    @property
    def salary(self):
        return self.__salary

    @salary.setter
    def salary(self,value):
        if(value <0):
            raise ValueError("Salary cannot be less than zero");
        self.__salary=value;

empObj1=Employee(101,"sara",5678,12345);
empObj1.printDetails();
print(empObj1.salary);
empObj1.salary=100;
print(empObj1.salary);
print(empObj1.aadhaarcard);
#empObj1.aadhaarcard=7890

empObj1.salary=-100

empObj1.salary=789

#read only property






    





#recordings -- check
#code --- github



