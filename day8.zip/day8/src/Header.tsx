import React from 'react'
import cgiLogo from "./cgiLogo.jpg"

class Header extends React.Component
{
    render()
    {
        return (
            <div className="container">
                <div className="row align-items-center text-center">
                    <img src={cgiLogo} alt="CGI Logo" className="col-4 img-responsive"/>

                    <h1 className="col-8"> Employee Management</h1>
                </div>
                
            </div>
        )
    }
}

export default Header;
