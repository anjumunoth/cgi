import React from 'react';
import logo from './logo.svg';
import './App.css';
import Home from "./Home"
import Menu from "./Menu"
import Footer from "./Footer"
import Header from "./Header"

function App() {
  return (
    <div >
      <Header></Header>
      <Menu></Menu>
      <Home></Home>
      <Footer></Footer>
    </div>
  );
}

export default App;
