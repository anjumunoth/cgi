import React from "react"
import "./Home.css"
import AddEmployee from "./AddEmployee"

// create a class component
interface Props{

}
interface State
{
    showDate:boolean;
    num1:number;
    showAddEmployee:boolean
}
class Home extends React.Component<Props,State>
{
    constructor(props:Props)
    {
        super(props);
        this.state={showDate:true,num1:1,showAddEmployee:false};
        //this.addItselfEventHandler=this.addItselfEventHandler.bind(this)
       
    }
    toggleDateEventHandler=()=>{
        // fat arrow function scope -- global scope -- component scope
        //this.showDate=!this.showDate;
        this.setState((prevState)=>{
            return {showDate:!prevState.showDate}
        },()=>{
            console.log("New showDate value "+this.state.showDate)//actual true(might expect - false)
        })
       
        // call render method again -- immutability
        // state 

    }
     addItselfEventHandler=(p1:number)=>{
        this.setState({num1:p1})

    }
     
    addEmployeeEventHandler=()=>{
        this.setState({showAddEmployee:true})
    }

//lifecycle method -- called implicitly
    render()
    {
        // return the virtual DOM
        var companyName:string="CGI"
        var numberOfCities:number=5;
       
        var emp={empId:101,empName:"sara"}
        var currentDate=(new Date()).toString()
        var employees=[{
            "empId": 101,
            "empName": "asha",
            "salary": 1001,
            "deptId": "D1"
        }, {
            "empId": 102,
            "empName": "Gaurav",
            "salary": 2000,
            "deptId": "D1"
        }, {
            "empId": 103,
            "empName": "Karan",
            "salary": 2000,
            "deptId": "D2"
        },
        {
            "empId": 104,
            "empName": "Kishan",
            "salary": 3000,
            "deptId": "D1"
        },
        {
            "empId": 105,
            "empName": "Keshav",
            "salary": 3500,
            "deptId": "D2"
        },
        {
            "empId": 106,
            "empName": "Pran",
            "salary": 4000,
            "deptId":null,
            "hobbies":["singing","dancing","cooking"],
            "isMarried":false
        },
        {
            "empId": 107,
            "empName": "Saurav",
            "salary": 3800
        }
    ];
        var trArr=employees.map((item)=>{
            return (
                <tr key={item.empId}>
                    <td>{item.empId}</td>
                    <td>{item.empName}</td>
                    <td>{item.salary}</td>
                    <td>
                        <input type="button" value="Edit" />
                    </td>
                </tr>
            )

        })
        var companyNameStyle={backgroundColor:"pink",color:"blue"}
        return (
            <div>
             {/*    <h1 style={companyNameStyle}> {companyName} </h1>
                <p style={{border:"5px solid blue"}}> Number of Cities {companyName.toLowerCase()} is present :{numberOfCities}</p>
                <p id="dateId"> Show date : {showDate?"true":"false"}</p>
                <p className="stylish"> Emp :{emp.empId}</p>
                {(2+2 ==4)?<h2>The condition is true</h2>:<h2>the condition is false</h2>}
                {showDate || currentDate} */}
                <table className="table" >
                    <thead>
                        <tr>
                            <td>Emp Id</td>
                            <td>Emp Name</td>
                            <td>Salary</td>
                            <td>Actions</td>
                        </tr>
                    </thead>
                    <tbody>
                       {trArr}
                    </tbody>
                </table>
                <input type="button" value="Add Employee" className="btn btn-primary"
                onClick={this.addEmployeeEventHandler} />
                <br/>
                {this.state.showDate && currentDate}
                <input type="button" value="Toggle date" onClick={this.toggleDateEventHandler} />
                <br/>
                {this.state.num1}<input type="button" value="Add itself" onClick={this.addItselfEventHandler.bind(this,100)}/>
                {this.state.showAddEmployee && <AddEmployee></AddEmployee> }
                
            </div>
        )
    }
}

export default Home;