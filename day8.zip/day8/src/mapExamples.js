//map

var arr1=[10,20,30,40,50]

var sqArr=arr1.map(function(item){
    return item*item
})

var sqArr1=arr1.map(function(item){
    if(item >30)
        return item*item
})
console.log(sqArr1)//[ud,ud,ud,1600,2500]

var employees=[{
    "empId": 101,
    "empName": "asha",
    "salary": 1001,
    "deptId": "D1"
}, {
    "empId": 102,
    "empName": "Gaurav",
    "salary": 2000,
    "deptId": "D1"
}, {
    "empId": 103,
    "empName": "Karan",
    "salary": 2000,
    "deptId": "D2"
},
{
    "empId": 104,
    "empName": "Kishan",
    "salary": 3000,
    "deptId": "D1"
},
{
    "empId": 105,
    "empName": "Keshav",
    "salary": 3500,
    "deptId": "D2"
},
{
    "empId": 106,
    "empName": "Pran",
    "salary": 4000,
    "deptId":null,
    "hobbies":["singing","dancing","cooking"],
    "isMarried":false
},
{
    "empId": 107,
    "empName": "Saurav",
    "salary": 3800
}
];

var resArr2=employees.map(function(item,index){
    return item.empId
})
console.log(resArr2);//[101,102... 107]

// fat arrow function -- anonymous function -- 1. less number of code; 2. lexical scope of"this"

f1=function(p1,p2){return p1+p2}

f1=(p1,p2) => {return p1+p2}

f1=p1=> {return p1+10}

f1=() => {return "hello cgi"}

f1=(p1,p2) => (p1+p2)

f1=p1=>p1.empId

var empIdArr=employees.map(item => item.empId)
var empId=999;
var obj={
    empId:101,
    empName:"sara",
    printDetails:function()
    {
        console.log("hello")
        console.log(this.empId)
        console.log(this.empName)
    },
    display:()=>{
        console.log("inside the fat arrow function")
        console.log("Employee Id:"+this.empId)
    }
}

obj.printDetails()
obj.display()






/*
1st iteration 
i=0; item = arr1[i]; execute the predicate function sqArr[i]=100

2nd iteration
i=1 item =arr1[i];sqArr[i]=400

sqArr=[100,400,900,1600,2500]

target arr and called Arr will have the same size
*/
