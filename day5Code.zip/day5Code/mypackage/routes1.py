import json
from mypackage import app

from flask import redirect, session,url_for,request,render_template,jsonify,make_response,g

@app.before_request
def openFile():
    session["username"]="root"
    print("G varaiable")
    print(g)
    g.postflag=False;
    if(request.method == "POST"):
        g.postflag=True;
    g.password="root"


@app.after_request
def closeFile(response):
    username=session["username"];
    password=g.password
    print("After request with session username"+username+password);
    print(g.postflag);
    return response;

