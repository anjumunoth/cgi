from werkzeug.utils import secure_filename
from mypackage import app
import os;

from flask import redirect, session,url_for,request,render_template,jsonify,make_response,g

@app.route("/upload")
def upload_file():
    return render_template("upload.html")

@app.route("/onupload",methods=["GET","POST"])
def onupload():
    if(request.method== "POST"):
        fileptr=request.files["myfile"]
        filename=secure_filename(fileptr.filename);
        fileptr.save(os.path.join(app.config["UPLOAD_FOLDER"],filename))
        return "file saved successfully"
