import json
from mypackage import app

from flask import redirect,url_for,request,render_template,jsonify,make_response



@app.route("/")
@app.route("/index",methods=["GET","POST"])
def index():
    return "Welcome to the server"



@app.route("/book/<name>/author/<authorname>")
def printbook(name,authorname):
    #return an dict -- json object
    # create a dict; convert into a json -- send that json
    bookDict={"bookName":name,"authorName":authorname,"hobbies":("h1","h2","h3")}
    return bookDict

@app.route("/product/<int:productId>")
def displayProductId(productId):
    return f"Product info of productId {productId}"   

@app.route("/admin")
def sayHelloAdmin():
    return "Hello admin"

@app.route("/guests/<name>")
def sayHelloGuest(name):
    return "Hello "+name


@app.route("/user/<name>")
def printuser(name):
    if(name =="admin"):
        return redirect(url_for("sayHelloAdmin"))
    else:
        return redirect(url_for("sayHelloGuest",name=name))

@app.route("/productInfo")
def productInfo():
    print(request);
    args=request.args
    str1=""
    for (k,v) in args.items():
        str1+=f"{k} : {v};"
    return "Product info received"+str1

@app.route("/welcomeuser/<name>")
def welcomeUser(name):
    return '''
    <html>
    <body>
        <h1> Welcome '''+name + ''' </h1>
    </body>
    </html>
    '''

@app.route("/login")
def loginpage():
    return render_template("login.html")

@app.route("/home")
def homepage():
    return render_template("home.html")

@app.route("/welcome/<name>/<int:marks>")
def welcome(name,marks):
    marksDict={"maths":24,"english":67,"social":88}
    return render_template("welcome.html",name=name,marks=marks,marksDict=marksDict)

@app.route("/about")
def about():
    return render_template("about.html",aboutcgi="CGI is a global company")

@app.route("/sitemap")
def sitemap():
    return render_template("sitemap.html")

@app.route("/emp")
def addemp():
    return render_template("employee.html")

empArr=[];
@app.route("/storedetails",methods=["POST","GET"])
def storedetails():
    #global empArr; if there is a global and local var with the same name'
    if(request.method =="POST"):
        formDetails=request.form;#dict
        if(formDetails == {}):
            formDetails=request.json
    else:
        formDetails=request.args;
    tempEmp={}
    tempEmp["empId"]=formDetails["empId"]
    tempEmp["empName"]=formDetails["empName"];
    empArr.append(tempEmp);
    empArrinJson=json.dumps(empArr)
    return jsonify(empArrinJson), 201

@app.route("/employees")
def getEmployees():
    return jsonify(empArr);

#put request
#/employees/101 ; body --- updated emp details
@app.route("/employees/<int:eId>",methods=["PUT"])
def emplyeePut(eId):
    updatedEmp=request.json;
    for i in range(len(empArr)):
        if(empArr[i]["empId"] == eId):
            empArr[i]=updatedEmp;
            return f"Employee details with empId {eId} updated successfully"
    else:
        return f"Employee details with empId {eId} not found"


@app.route("/employees/<int:eId>",methods=["DELETE"])
def employeesDelete(eId):
    print("Employee id in delete",eId);
    pos=-1;
    isPresent=False;
    for i in range(len(empArr)):
        print(empArr[i])
        if(empArr[i]["empId"] == eId):
            pos=i;
            isPresent=True;
            break;
    print("Emp Arr")
    print(empArr);
    print("Pos :",pos)
    if(isPresent == True):
        empArr.pop(pos)
        return f"Emp Id {eId} deleted"
    else:
        return f"Emp Id {eId} not found"

@app.errorhandler(404)
def notfound(error):
    return "Page not found",404

@app.errorhandler(500)
def internalerror(error):
    return "Internal server error",500 


@app.route("/cookie")
def cookie():
    return render_template("cookie.html")

@app.route("/setcookie",methods=["GET","POST"])
def setcookie():
    if (request.method=="POST"):
        username=request.form["username"];
    resp=make_response(render_template("readcookie.html"))
    resp.set_cookie("Username",username);
    return resp;

@app.route("/getcookie")
def getcookie():
    username=request.cookies.get("Username");
    return "<h1> Welcome"+username+"</h1>"


# request header info
# get request -- cant send data as part of body 
# get request -- params, query string ?name=sara&authorname=paulcoelho

# redirect to  a url
#flask redirect to a view function
# params : int, float, path

# {{}}  -- value in a var
# {% %} -- for statement
# {{ block nameBlock}}