class Config(object):
    SECRET_KEY="this is a secret key"
    UPLOAD_FOLDER="./uploads"
    MAX_CONTENT_PATH="43567890989765645"