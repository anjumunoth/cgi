print("Thank u god")
print("sorry god")
